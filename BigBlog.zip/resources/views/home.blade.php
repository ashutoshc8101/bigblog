@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    @foreach($blogs as $blog)
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <img src="{{ $blog->banner }}" width="100%" />
                <div class="panel-body">
                    <h3>{{ $blog->title }}</h3>
                    <p>Posted by <b><a href="{{ @route('user', $blog->user->id) }}">{{ $blog->user->name }}</a></b> - {{ $blog->created_at->diffForHumans() }}</p>
                    <a href="{{ @route('blog', $blog->slug) }}" class="btn btn-primary">Read full article</a>

                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection

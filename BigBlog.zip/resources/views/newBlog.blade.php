@extends('layouts.app')

@section('scripts')
<script src="/tags/bootstrap-tagsinput.js"></script>
<script src="/tinymce/tinymce.min.js"></script>
<script>tinymce.init({ selector:'.editor', plugins: [
    'advlist autolink lists link image charmap print preview hr anchor pagebreak',
    'searchreplace wordcount visualblocks visualchars code fullscreen',
    'insertdatetime media nonbreaking save table contextmenu directionality',
    'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help fullpage'
  ],
  toolbar: "undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media | forecolor backcolor emoticons | codesample help",
  theme_advanced_buttons3_add : "fullpage",
  image_advtab: true
 });

 $('#tags-input').tagsinput({
    confirmKeys: [188]
  });

 </script>

@endsection

@section('styles')
    <link rel="stylesheet" type="text/css" href="/tags/bootstrap-tagsinput.css" />
    <style>
        .editor{
            height: 400px;
        }
    </style>
@endsection

@section('content')

<div class="container">
    <div class="panel panel-default">
        <h1 style="text-align: center">Write your own blog !!</h1>
        <div class="panel-body">
            <form action="{{ @route('post') }}" id="newForm" method="post">
            {{ csrf_field() }}
            <div class="form-group">
            <div class="row">
                <label for="title" class="col-md-4">Title :</label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="title">
                    </div>
                </div>
            </div>
            <div class="form-group">
            <div class="row">
                <label for="banner" class="col-md-4">Banner Url : </label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="banner">
                    </div>
                </div>
            </div>
            <div class="form-group">
            <div class="row">
                <label for="tags" class="col-md-4">Tags : </label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="tags" id="tags-input" data-role="tagsinput" style="display: block; width: 100% !important;">
                    </div>
                </div>
            </div>

            <textarea class="editor" name="markup"></textarea>
            <input type="submit" value="Post" class="btn btn-primary">
            </form>
            </div>
        </div>
    </div>
</div>

@endsection
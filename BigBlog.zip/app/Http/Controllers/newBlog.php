<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use App\Blog;

class newBlog extends Controller
{
    public function index(Request $Request, Response $Response){
        $blog = Blog::where('id', 1)->first();
        return view('newBlog');
    }

    public function post(Request $Request, Response $Response){
        /*
        $this->validate($Request, [
        'title' => 'required|unique:blogs',
        'banner' => 'required',
        'markup' => 'required',
        'tags' => 'required'
    ]); */

        $tags = explode(',', $Request->tags);

        foreach($tags as $tag){
            $tagk = \App\Blog::whereHas('tags', function ($query) use ($tag) {
            $query->where('name', '=', strtoupper($tag));
        })->get();
            var_dump($tagk);
            foreach($tagk as $k){
               if($k->exists){
                
               }
            }
        }

        


        die();

        $blog = new \App\Blog;

        $blog->slug = str_slug($Request->title);
        $blog->title = $Request->title;
        $blog->banner = $Request->banner;
        $blog->body = $Request->markup;
        $blog->user_id = Auth::id();
        $blog->save();

        return redirect()->route('home');
    }

}

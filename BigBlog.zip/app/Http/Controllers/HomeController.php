<?php 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Blog;

class homeController extends Controller{


    public function index(Request $Request, Response $Response){
        $blogPosts = Blog::all();

        return view('home' , ['blogs' => $blogPosts]);
    }

    public function getAll(Request $Request, Response $Response){
	    return "<h1>Hello Notepad</h1>";
    }


    public function blog(Request $Request, Response $Response, $slug){
        $blog = Blog::where('slug', $slug)->first();
        return view('blog', ['blog' => $blog]);
    }

}
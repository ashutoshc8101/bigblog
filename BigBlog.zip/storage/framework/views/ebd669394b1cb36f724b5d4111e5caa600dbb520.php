<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <img src="<?php echo e($blog->banner); ?>" width="100%" />
                <div class="panel-body">
                    <h3><?php echo e($blog->title); ?></h3>
                    <p>Posted by <b><a href="<?php echo e(@route('user', $blog->user->id)); ?>"><?php echo e($blog->user->name); ?></a></b> - <?php echo e($blog->created_at->diffForHumans()); ?></p>
                    <a href="<?php echo e(@route('blog', $blog->slug)); ?>" class="btn btn-primary">Read full article</a>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.11.0/styles/tomorrow-night.min.css">
    <style>
        pre{
            padding: 0;
        }
        a.tag{
            border: 2px solid #aaa;
            padding: 10px;
            border-radius: 10px;
            color: #333;
            font-weight: 500;
            text-decoration: none;
            transition: border 0.3s;
        }

        a.tag:hover{
            text-decoration: none;
            border: 2px solid #555;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="panel panel-default">
        <div class="panel-body">
            <h1 align="center"><?php echo e($blog->title); ?></h1>
            <img src="<?php echo e($blog->banner); ?>" width="100%">
            <h2>Posted by <b><a href="<?php echo e(@route('user', $blog->user->id)); ?>"><?php echo e($blog->user->name); ?></a></b> <?php echo e($blog->created_at->diffForHumans()); ?></h2>
            <hr>
            <?php $__currentLoopData = $blog->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(@route('tag', $tag->slug)); ?>" class="tag"><?php echo e($tag->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
            
            <article>
                <?php echo $blog->body; ?>

            </article>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.11.0/highlight.min.js"></script>
    <script>hljs.initHighlightingOnLoad();</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>